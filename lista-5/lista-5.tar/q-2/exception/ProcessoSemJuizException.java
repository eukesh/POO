package exception;

public class ProcessoSemJuizException extends Exception{
    public ProcessoSemJuizException(String mensagem){
        super(mensagem);
    }
}
