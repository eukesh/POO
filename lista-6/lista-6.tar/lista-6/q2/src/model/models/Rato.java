package model.models;

public class Rato implements Animal{
    @Override
    public String emitirSom() {
        return "Squid-Squid";
    }
}
