package model.models;

public enum Animais {
    CAO,COBRA,GATO,RATO,SAPO;
}
