package model.models;

public interface Animal {

    public String emitirSom();
}
