package model.models;

public class Cobra implements Animal{
    @Override
    public String emitirSom() {
        return "Shhh-Shhh";
    }
}
