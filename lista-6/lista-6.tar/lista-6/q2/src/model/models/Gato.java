package model.models;

public class Gato implements Animal{
    @Override
    public String emitirSom() {
        return "Miau-miau";
    }
}
