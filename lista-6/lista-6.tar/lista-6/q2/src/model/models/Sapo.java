package model.models;

public class Sapo implements Animal{
    @Override
    public String emitirSom() {
        return "Rhebt-Rhebt";
    }
}
