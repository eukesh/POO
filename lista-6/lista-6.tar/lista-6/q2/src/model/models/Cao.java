package model.models;

public class Cao implements Animal{

    @Override
    public String emitirSom() {
        return "Au-au";
    }
}
