package models;

public interface Observador {

    public void atualizar(Object obj);
}
