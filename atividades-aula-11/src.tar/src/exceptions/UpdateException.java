package exceptions;

public class UpdateException extends Exception{
    public UpdateException(String mensagem){
        super(mensagem);
    }
}
